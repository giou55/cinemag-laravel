<header>
    <div class="container d-flex justify-content-between align-items-center" id="header">
        <div class="d-flex justify-content-between align-items-center links-1">
            <div><a href="https://www.in.gr" target="_blank">IN.GR</a></div>
            <div class="divider"></div>
            <div><a href="https://www.zougla.gr" target="_blank">ZOUGLA</a></div>
            <div class="divider"></div>
            <div><a href="https://www.athensvoice.gr" target="_blank">ATHENS VOICE</a></div>
            <div class="divider"></div>
            <div><a href="https://www.oneman.gr" target="_blank">ONEMAN</a></div>
            
        </div>
            
        <div>
            <span style="font-size: 1.4rem; font-family: 'Mystery Quest', cursive;">ATHENS</span>
        </div>

        <div class="d-flex justify-content-between align-items-center links-1">
            <div><a href="https://www.lifo.gr" target="_blank">LIFO</a></div>
            <div class="divider"></div>
            <div><a href="https://www.cinemagazine.gr" target="_blank">CINEMAGAZINE</a></div>
            <div class="divider"></div>
            <div><a href="https://www.athinorama.gr" target="_blank">ATHINORAMA</a></div>
            
            <div class="d-flex justify-content-between align-items-center links-2">
                    <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                            
                            <a class="modal_link" data-toggle="modal" data-target="#loginModal"><?php echo e(__('Login')); ?></a>
                        <?php endif; ?>

                        <div class="divider"></div>

                        <?php if(Route::has('register')): ?>
                            
                            <a class="modal_link" data-toggle="modal" data-target="#registerModal"><?php echo e(__('Register')); ?></a>
                        <?php endif; ?>

                    <?php else: ?>
                        <a><?php echo e(Auth::user()->nickname); ?></a>
                        <div class="divider"></div>
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php endif; ?>
            </div>
        </div>

        <?php echo $__env->make('includes.login_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.register_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <div class="container d-flex justify-content-end align-items-center" id="subscription">
        <span>Less than $5 per month</span>
    </div>
</header><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/includes/header.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
        <div class="container" style="position: relative;">
            <div class="posts-title-container">
                <h1 class="posts-title"><?php echo e($title); ?></h1>
            </div>
                
            <div class="row pt-5">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 post-container">
                        <div class="mb-3">
                        <?php if($post->image): ?>
                            <img src="/storage/images/<?php echo e($post->image); ?>" class="img-fluid mb-2" alt="">
                        <?php endif; ?>
                            <a href="<?php echo e(route('post', $post)); ?>"><?php echo e($post->title); ?></></a>
                            <p class="post-body"><?php echo e($post->body); ?></p>
                            <p class="post-editor"><?php echo e($post->user->fullname); ?></p>
                            <p>Κατηγορία: <?php echo e($post->category->title); ?></p>
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/posts.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
        <div class="container-sm">

            <div class="row header-border mb-3">
                <div class="col-md-4">
                    <h2>Κατηγορίες</h2>
                </div>  
            </div>

            <div class="row">
                <div class="col-md-8">

                    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <table class="table table-borderless table-sm">
                        <thead>
                            <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Όνομα</th>
                            <th scope="col">URL</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($category->id); ?></td>
                                    <td><?php echo e($category->title); ?></td>
                                    <td><?php echo e($category->url); ?></td>
                                    <td>
                                        <?php if(Auth::user()->email == env('ADMIN_EMAIL')): ?>
                                            <a href="<?php echo e(route('category.edit', $category)); ?>"><button class="btn btn-primary btn-sm">Επεξεργασία</button></a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(Auth::user()->email == env('ADMIN_EMAIL')): ?>
                                            <a href="<?php echo e(route('category.delete', $category)); ?>"><button class="btn btn-danger btn-sm">Διαγραφή</button></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/admin/categories.blade.php ENDPATH**/ ?>
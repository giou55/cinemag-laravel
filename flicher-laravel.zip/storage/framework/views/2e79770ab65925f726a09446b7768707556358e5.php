

<?php $__env->startSection('content'); ?>
        <div class="container-sm post-item">
            <div class="row">
                    <div class="col-12 post-headers">
                        <div><?php echo e($post->created_at->format('d/m/Y')); ?></div>
                        <h1><?php echo e($post->title); ?></h1>
                        <p>Συντάκτης: <?php echo e($post->user->fullname); ?></p>
                    </div>
            </div>

            <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                        <?php if($post->image): ?>
                            <img src="/storage/images/<?php echo e($post->image); ?>" alt="">
                        <?php endif; ?>
                        <p>Κατηγορία: <?php echo e($post->category->title); ?></p>
                        <p><?php echo e($post->body); ?></p>
                    </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/post.blade.php ENDPATH**/ ?>
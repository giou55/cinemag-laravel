<footer>

    <div class="container d-flex justify-content-center align-items-center" id="footer-nav">
            <div>
                <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('images/logo-title.png')); ?>" alt=""></a>
            </div>
            <div class="divider"></div>
            <div><a href="<?php echo e(route('posts', 'cinema')); ?>">ΣΙΝΕΜΑ</a></div>
            <div class="divider"></div>
            <div><a href="<?php echo e(route('posts', 'theater')); ?>">ΘΕΑΤΡΟ</a></div>
            <div class="divider"></div>
            <div><a href="<?php echo e(route('posts', 'music')); ?>">ΜΟΥΣΙΚΗ</a></div>
            <div class="divider"></div>
            <div><a href="<?php echo e(route('posts', 'youtube')); ?>">YOUTUBE</a></div>
            <div class="divider"></div>
            <div><a href="<?php echo e(route('posts', 'books')); ?>">ΒΙΒΛΙΑ</a></div>
            <div class="divider"></div>
            <div><a href="<?php echo e(route('posts', 'podcasts')); ?>">PODCASTS</a></div>
    </div>

    <div class="container d-flex justify-content-center align-items-center" id="footer-social">
        <svg width="38" height="38" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg">
            <g fill="none" fill-rule="nonzero">
                <circle fill="#000" cx="19" cy="19" r="19"></circle>
                <path d="M20.788 28.998V19.42h3.538l.532-3.734h-4.07v-2.383c0-1.08.33-1.817 2.036-1.817H25v-3.34A32.453 32.453 0 0 0 21.832 8c-3.138 0-5.285 1.74-5.285 4.934v2.753H13v3.735h3.547V29h4.24v-.002z" fill="#FFF"> 
                </path>
            </g>
        </svg>

        <svg width="38" height="38" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg">
            <g fill="none" fill-rule="nonzero">
                <circle fill="#000" cx="19" cy="19" r="19"></circle>
                <path d="M29.042 12.736a7.442 7.442 0 0 1-2.127.583 3.695 3.695 0 0 0 1.629-2.048 7.417 7.417 0 0 1-2.351.898 3.701 3.701 0 0 0-6.308 3.376 10.504 10.504 0 0 1-7.629-3.868 3.69 3.69 0 0 0-.501 1.861 3.7 3.7 0 0 0 1.646 3.081 3.711 3.711 0 0 1-1.676-.462v.047a3.703 3.703 0 0 0 2.969 3.628 3.643 3.643 0 0 1-1.671.066 3.706 3.706 0 0 0 3.458 2.57A7.439 7.439 0 0 1 11 24a10.46 10.46 0 0 0 5.675 1.662c6.81 0 10.531-5.642 10.531-10.53 0-.161-.004-.321-.011-.48a7.544 7.544 0 0 0 1.847-1.916" fill="#FFF">
                </path>
            </g>
        </svg>

        <svg width="38" height="38" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg">
            <circle fill="#000" cx="19" cy="19" r="19"></circle>
            <g transform="translate(10 10.03)">
                <path d="M5.288.06C4.33.103 3.676.256 3.104.478A4.41 4.41 0 0 0 1.51 1.516 4.41 4.41 0 0 0 .472 3.109C.25 3.682.098 4.336.054 5.293.01 6.253 0 6.56 0 9.003c0 2.443.01 2.75.054 3.71.044.957.196 1.611.418 2.183A4.41 4.41 0 0 0 1.51 16.49c.5.5 1.002.808 1.594 1.038.572.222 1.226.374 2.184.418.96.044 1.266.054 3.71.054 2.443 0 2.749-.01 3.709-.054.957-.044 1.611-.196 2.184-.418a4.411 4.411 0 0 0 1.593-1.038c.5-.5.808-1.002 1.038-1.594.222-.572.375-1.226.418-2.184.044-.96.054-1.266.054-3.71 0-2.443-.01-2.749-.054-3.709-.043-.957-.196-1.611-.418-2.184a4.41 4.41 0 0 0-1.038-1.593A4.41 4.41 0 0 0 14.891.478C14.318.256 13.664.103 12.707.06c-.96-.044-1.266-.054-3.71-.054-2.443 0-2.75.01-3.71.054zm7.345 1.62c.877.04 1.353.186 1.67.309.42.163.72.358 1.035.673.315.315.51.615.673 1.035.123.317.27.793.31 1.67.043.949.052 1.233.052 3.636 0 2.402-.009 2.687-.052 3.635-.04.878-.187 1.354-.31 1.671-.163.42-.358.72-.673 1.035-.315.314-.615.51-1.035.673-.317.123-.793.27-1.67.31-.949.043-1.233.052-3.636.052-2.402 0-2.687-.01-3.635-.053-.878-.04-1.354-.186-1.671-.31a2.788 2.788 0 0 1-1.035-.672 2.788 2.788 0 0 1-.673-1.035c-.123-.317-.27-.793-.31-1.67-.043-.95-.052-1.234-.052-3.636 0-2.403.01-2.687.053-3.636.04-.877.186-1.353.31-1.67.163-.42.358-.72.672-1.035.315-.315.615-.51 1.035-.673.317-.123.793-.27 1.67-.31.95-.043 1.234-.052 3.636-.052 2.403 0 2.687.009 3.636.052z" fill="#FFF">
                </path>
            </g>
            <path d="M18.997 22.032a3 3 0 1 1 0-5.998 3 3 0 0 1 0 5.998m0-7.62a4.62 4.62 0 1 0 0 9.241 4.62 4.62 0 0 0 0-9.24M24.88 14.23a1.08 1.08 0 1 1-2.16 0 1.08 1.08 0 0 1 2.16 0" fill="#FFF">
            </path>
        </svg>

        <svg width="38" height="38" xmlns="http://www.w3.org/2000/svg">
            <g fill="none" fill-rule="evenodd">
                <path d="M19 0c10.493 0 19 8.506 19 19 0 10.493-8.507 19-19 19C8.506 38 0 29.493 0 19 0 8.506 8.506 0 19 0" fill="#000">
                </path>
                <g fill="#FFF">
                    <path d="M17.527 23.602A2.014 2.014 0 1 1 13.5 23.6a2.014 2.014 0 0 1 4.028 0M13.5 15.638v2.784s6.759.19 6.969 7.193h2.976s.351-9.518-9.945-9.977">
                    </path>
                    <path d="M13.5 10.522v2.836s10.996-.175 12.222 12.257h2.766s.316-14.253-14.988-15.093">
                    </path>
                </g>
            </g>
        </svg>
    </div>

    <div class="container d-flex justify-content-center align-items-center" id="footer-copy">
        FLICHER IS A VOX MEDIA NETWORK. © 2021 VOX MEDIA, LLC. ALL RIGHTS RESERVED.
    </div>

</footer><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/includes/footer.blade.php ENDPATH**/ ?>
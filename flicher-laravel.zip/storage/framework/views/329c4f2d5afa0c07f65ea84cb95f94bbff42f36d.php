

<?php $__env->startSection('content'); ?>
        <div class="container p-5">
            <div class="row mb-3">
                <div class="col-6">
                    <div>Εμφανίζονται όλα τα αποτελέσματα για:</div>
                    <form class="d-flex" method="GET" action="<?php echo e(route('search')); ?>">
                        <input class="form-control form-control-lg mr-2" type="search" aria-label="Search" value="<?php echo e($q); ?>" name="q">
                        <button class="btn btn-outline-primary btn-lg" type="submit">Υποβολή</button>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-8">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex">
                        <?php if($post->image): ?>
                            <div class="col-6">
                                <img src="/storage/images/<?php echo e($post->image); ?>" class="img-fluid" alt="">
                            </div>
                        <?php endif; ?>
            
                        <div class="col-6">
                            <p>Κατηγορία: <?php echo e($post->category->title); ?></p>
                            <h5><a href="<?php echo e(route('post', $post)); ?>"><?php echo e($post->title); ?></a></h5>
                            <p class="card-text"><?php echo e($post->body); ?></p>
                            <p class="card-text">Συντάκτης: <?php echo e($post->user->fullname); ?></p>
                        </div>
                    </div>
                    <br><hr><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/search.blade.php ENDPATH**/ ?>
<div id="admin" class="d-flex justify-content-between align-items-center">

    <div class="d-flex justify-content-start align-items-center">
        <span>Πίνακας Ελέγχου</span>
        <a href="<?php echo e(route('posts.all')); ?>">Άρθρα</a>
        <a href="<?php echo e(route('categories')); ?>">Κατηγορίες</a>
        <a href="<?php echo e(route('post.new')); ?>">Νέο άρθρο</a>
        <?php if(Auth::user()->email == env('ADMIN_EMAIL')): ?>
            <a href="<?php echo e(route('category.new')); ?>">Νέα κατηγορία</a>
        <?php endif; ?>
        <a href="<?php echo e(route('users')); ?>">Χρήστες</a>
    </div>

    <div>
        <a><?php echo e(Auth::user()->fullname); ?></a>

        <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>
        <form id="admin-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </div>

</div>
<?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/includes/admin.blade.php ENDPATH**/ ?>
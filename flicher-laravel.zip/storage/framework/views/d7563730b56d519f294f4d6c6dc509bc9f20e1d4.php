

<?php $__env->startSection('content'); ?>
    <div class="container-sm">

            <div class="row header-border mb-3">
                <div class="col-md-6">
                    <h2>Νέο άρθρο</h2>
               </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="title">Τίτλος</label>
                            <input class="form-control" type="text" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="title">Υπότιτλος</label>
                            <input class="form-control" type="text" name="subtitle">
                        </div>
                        <div class="mb-3">
                            <label for="category">Κατηγορία</label>
                            <select class="form-control" name="category">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="body">Κείμενο</label>
                            <textarea class="form-control" name="body" rows="10" cols="30" required></textarea>
                        </div>
                        <div class="mb-3">
                            <input class="form-control" type="file" name="photo">
                        </div>
                        <button class="btn btn-primary mb-3" type="submit">Υποβολή</button>
                    </form>
                </div>
            </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/admin/new_post.blade.php ENDPATH**/ ?>
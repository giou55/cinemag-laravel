<div class="container d-flex justify-content-between align-items-center logo-category">

    <?php echo $__env->make('includes.menu_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="logo">
        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('images/logo-title.png')); ?>" alt=""></a>
    </div>

    <?php echo $__env->make('includes.search_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</div><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/includes/logo_posts.blade.php ENDPATH**/ ?>
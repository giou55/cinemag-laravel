<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
  
<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger" role="alert">
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>

<?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/includes/message.blade.php ENDPATH**/ ?>
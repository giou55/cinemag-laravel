<div class="menu">
    <div class="open-menu">
        <img class="active" src="<?php echo e(asset('images/menu-icon-active.jpg')); ?>" alt="">
        <img src="<?php echo e(asset('images/menu-icon-inactive.jpg')); ?>" alt="">
    </div>
    <div class="menu-content">
        <div class="close-menu">
            <img class="active" src="<?php echo e(asset('images/menu-icon-close-active.jpg')); ?>" alt="">
            <img src="<?php echo e(asset('images/menu-icon-close-inactive.jpg')); ?>" alt="">
        </div>
        <div class="menu-links">
            <div><a href="<?php echo e(route('posts', 'cinema')); ?>">ΣΙΝΕΜΑ</a></div>
            <div><a href="<?php echo e(route('posts', 'theater')); ?>">ΘΕΑΤΡΟ</a></div>
            <div><a href="<?php echo e(route('posts', 'music')); ?>">ΜΟΥΣΙΚΗ</a></div>
            <div><a href="<?php echo e(route('posts', 'youtube')); ?>">YOUTUBE</a></div>
            <div><a href="<?php echo e(route('posts', 'books')); ?>">ΒΙΒΛΙΑ</a></div>
            <div><a href="<?php echo e(route('posts', 'podcasts')); ?>">PODCASTS</a></div>
        </div>
    </div>
</div><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/includes/menu_popup.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
        
        
        
        <div class="container-sm">

            <div class="row header-border mb-3">
                <div class="col-md-4">
                    <h2>Χρήστες</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table class="table table-borderless admin-users">
                        <thead>
                            <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Ονοματεπώνυμο</th>
                            <th scope="col">Ψευδώνυμο</th>
                            <th scope="col">Email</th>
                            <th scope="col">Κατάσταση</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->fullname); ?></td>
                                    <td><?php echo e($user->nickname); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e(($user->is_activated) ? ' Ενεργοποιημένος' : 'Απενεργοποιημένος'); ?></td>
                                    <td>
                                        <?php if(Auth::user()->email == env('ADMIN_EMAIL')): ?>
                                            <a href="<?php echo e(route('user.edit', $user)); ?>"><button class="btn btn-primary btn-sm">Επεξεργασία</button></a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(Auth::user()->email == env('ADMIN_EMAIL') && Auth::user()->email !== $user->email): ?>
                                            <a href="<?php echo e(route('user.delete', $user)); ?>"><button class="btn btn-danger btn-sm">Διαγραφή</button></a>
                                        <?php endif; ?>
                                    </td>

                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/admin/users.blade.php ENDPATH**/ ?>
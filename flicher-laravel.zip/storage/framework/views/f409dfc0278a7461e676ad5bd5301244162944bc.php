

<?php $__env->startSection('content'); ?>
    <div class="container-sm">

        <div class="row header-border mb-3">
            <div class="col-md-6">
                <h2>Επεξεργασία χρήστη</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <?php if(isset($text)): ?>
                    <p id="edit-message"><?php echo e($text); ?></p>
                <?php endif; ?>
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="id">ID</label>
                        <input class="form-control" type="text" name="id" value="<?php echo e($user->id); ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="fullname">Ονοματεπώνυμο</label>
                        <input class="form-control" type="text" name="fullname" value="<?php echo e($user->fullname); ?>">
                    </div>
                     <div class="mb-3">
                        <label for="nickname">Ψευδώνυμο</label>
                        <input class="form-control" type="text" name="nickname" value="<?php echo e($user->nickname); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email">Email</label>
                        <input class="form-control" type="text" name="email" value="<?php echo e($user->email); ?>" <?php echo e(($user->email == env('ADMIN_EMAIL')) ? ' readonly' : ''); ?>>
                    </div>
                    <div class="mb-3">
                        

                        
                        
                        <label for="status">Κατάσταση</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" value="1" name="status" id="flexRadioDefault1" <?php echo e(($user->is_activated) ? ' checked' : ''); ?>>
                            <label class="form-check-label" for="flexRadioDefault1">
                                Ενεργοποιημένος
                            </label>
                            </div>
                            <div class="form-check">
                            <input class="form-check-input" type="radio" value="0" name="status" id="flexRadioDefault2" <?php echo e((!$user->is_activated) ? ' checked' : ''); ?> <?php echo e(($user->email == env('ADMIN_EMAIL')) ? ' disabled' : ''); ?>>
                            <label class="form-check-label" for="flexRadioDefault2">
                                Απενεργοποιημένος
                            </label>
                        </div>

                    </div>
                    <button class="btn btn-primary mb-3" type="submit">Αποθήκευση</button>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\G.Giourmetakis\Desktop\Projects\1.MyProjects\flicher-laravel\resources\views/admin/edit_user.blade.php ENDPATH**/ ?>